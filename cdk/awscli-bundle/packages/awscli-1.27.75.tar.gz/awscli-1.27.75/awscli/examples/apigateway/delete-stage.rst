**To delete a stage in an API**

Command::

  aws apigateway delete-stage --rest-api-id 1234123412 --stage-name 'dev'
